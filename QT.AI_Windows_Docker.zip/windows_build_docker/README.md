# QT.AI Trading Bot - Windows Docker Setup

This directory contains the necessary files to run the QT.AI Trading Bot using Docker on Windows 11.

## Prerequisites

1. **Windows 11**
   - Make sure your system is updated to the latest version

2. **Docker Desktop for Windows**
   - Download and install from [docker.com](https://www.docker.com/products/docker-desktop)
   - During installation, make sure to enable WSL2 integration
   - After installation, switch to Windows containers (right-click Docker icon in system tray > Switch to Windows containers...)

## Installation Steps

1. **Run the Build Script**
   - Double-click on `build_windows_docker.bat`
   - This will build and start the Docker containers

2. **Access the Application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000

## Troubleshooting

### Docker Desktop Issues

- Make sure Docker Desktop is running
- Ensure you've switched to Windows containers
- Check Docker Desktop logs for errors

### Container Build Failures

- Make sure you have a stable internet connection
- Try running the build script again
- Check Windows Firewall settings

### Container Access Issues

- Make sure ports 3000 and 8000 are not in use by other applications
- Check Windows Firewall settings
- Restart Docker Desktop

## Manual Commands

If you prefer to run commands manually:

```
# Build the containers
docker-compose -f docker-compose.windows.yml build

# Start the containers
docker-compose -f docker-compose.windows.yml up -d

# View container logs
docker-compose -f docker-compose.windows.yml logs

# Stop the containers
docker-compose -f docker-compose.windows.yml down
```

## Files Included

- `Dockerfile.backend.windows` - Windows-compatible Dockerfile for the backend
- `Dockerfile.frontend.windows` - Windows-compatible Dockerfile for the frontend
- `docker-compose.windows.yml` - Docker Compose configuration for Windows
- `build_windows_docker.bat` - Build script for Windows
- `requirements.txt` - Python dependencies for the backend
