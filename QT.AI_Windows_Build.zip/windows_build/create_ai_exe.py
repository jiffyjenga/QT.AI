import sys
from app.ai.models.lstm_model import LSTMModel
from app.ai.sentiment.sentiment_analyzer import SentimentAnalyzer
import numpy as np

def main():
    print("QT.AI - AI and Sentiment Analysis Module")
    print("----------------------------------------")
    
    # Initialize LSTM model
    lstm_model = LSTMModel(input_dim=5, hidden_dim=64, output_dim=1)
    print("LSTM Model initialized")
    
    # Generate sample data
    sample_data = np.random.random((10, 5))
    print("Sample data shape:", sample_data.shape)
    
    # Make prediction
    predictions = lstm_model.predict(sample_data)
    print("Predictions shape:", predictions.shape)
    
    # Initialize sentiment analyzer
    sentiment_analyzer = SentimentAnalyzer()
    print("Sentiment Analyzer initialized")
    
    # Analyze sample text
    sample_text = "The market is looking very bullish today with strong momentum"
    sentiment = sentiment_analyzer.analyze_text(sample_text)
    print("Sample text sentiment:", sentiment)
    
    print("\nAI and Sentiment Analysis module is working correctly")
    input("Press Enter to exit...")

if __name__ == "__main__":
    main()
