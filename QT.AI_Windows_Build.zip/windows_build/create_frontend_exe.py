import sys
import os
import webbrowser
import http.server
import socketserver
import threading
import time

def start_server():
    PORT = 8080
    Handler = http.server.SimpleHTTPRequestHandler
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"Serving at port {PORT}")
        httpd.serve_forever()

def main():
    print("QT.AI - Frontend Demo")
    print("--------------------")
    
    # Create a simple HTML file to demonstrate the frontend
    os.makedirs("frontend_demo", exist_ok=True)
    with open("frontend_demo/index.html", "w") as f:
        f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QT.AI Trading Bot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .dashboard {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            padding: 20px;
        }
        .chart {
            height: 300px;
            background-color: #ecf0f1;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .trades {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <header>
        <h1>QT.AI Trading Bot</h1>
        <p>Advanced Multi-Asset Trading Platform</p>
    </header>
    
    <div class="container">
        <div class="dashboard">
            <div class="card">
                <h2>Market Overview</h2>
                <div class="chart">
                    <p>Price Chart Placeholder</p>
                </div>
            </div>
            <div class="card">
                <h2>Portfolio Performance</h2>
                <div class="chart">
                    <p>Performance Chart Placeholder</p>
                </div>
            </div>
        </div>
        
        <div class="card trades">
            <h2>Recent Trades</h2>
            <table>
                <thead>
                    <tr>
                        <th>Asset</th>
                        <th>Type</th>
                        <th>Price</th>
                        <th>Amount</th>
                        <th>Time</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>BTC/USD</td>
                        <td>Buy</td>
                        <td>$65,432.10</td>
                        <td>0.15</td>
                        <td>10:30:45</td>
                        <td>Completed</td>
                    </tr>
                    <tr>
                        <td>ETH/USD</td>
                        <td>Sell</td>
                        <td>$3,456.78</td>
                        <td>2.5</td>
                        <td>10:15:22</td>
                        <td>Completed</td>
                    </tr>
                    <tr>
                        <td>AAPL</td>
                        <td>Buy</td>
                        <td>$187.45</td>
                        <td>10</td>
                        <td>09:45:12</td>
                        <td>Pending</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="card">
            <h2>Trading Controls</h2>
            <button class="btn">Start Automated Trading</button>
            <button class="btn">Place Manual Order</button>
            <button class="btn">View AI Predictions</button>
        </div>
    </div>
    
    <script>
        // Simulate real-time updates
        setInterval(() => {
            const now = new Date();
            const time = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
            
            // Add a new trade randomly
            if (Math.random() > 0.7) {
                const assets = ['BTC/USD', 'ETH/USD', 'SOL/USD', 'AAPL', 'MSFT', 'GOOGL'];
                const types = ['Buy', 'Sell'];
                const statuses = ['Completed', 'Pending'];
                
                const asset = assets[Math.floor(Math.random() * assets.length)];
                const type = types[Math.floor(Math.random() * types.length)];
                const price = '$' + (Math.random() * 10000).toFixed(2);
                const amount = (Math.random() * 10).toFixed(2);
                const status = statuses[Math.floor(Math.random() * statuses.length)];
                
                const table = document.querySelector('tbody');
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                    <td>${asset}</td>
                    <td>${type}</td>
                    <td>${price}</td>
                    <td>${amount}</td>
                    <td>${time}</td>
                    <td>${status}</td>
                `;
                
                table.insertBefore(newRow, table.firstChild);
                
                // Remove the last row if there are more than 10
                if (table.children.length > 10) {
                    table.removeChild(table.lastChild);
                }
            }
        }, 3000);
    </script>
</body>
</html>
""")
    print("Created frontend demo files")
    
    # Start a simple HTTP server in a separate thread
    server_thread = threading.Thread(target=start_server)
    server_thread.daemon = True
    server_thread.start()
    
    # Give the server a moment to start
    time.sleep(1)
    
    # Open the browser
    print("Opening frontend demo in browser...")
    webbrowser.open("http://localhost:8080/frontend_demo/")
    
    print("\nFrontend demo is running")
    print("Press Ctrl+C to exit")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nExiting frontend demo")

if __name__ == "__main__":
    main()
