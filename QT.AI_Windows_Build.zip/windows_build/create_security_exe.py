import sys
from app.security.encryption.key_manager import KeyManager
from app.security.auth.jwt_handler import JWTHandler

def main():
    print("QT.AI - Security Module")
    print("----------------------")
    
    # Initialize key manager
    key_manager = KeyManager()
    print("Key Manager initialized")
    
    # Encrypt sample API key
    api_key = "sample_api_key_123"
    encrypted_key = key_manager.encrypt_api_key(api_key)
    print("Encrypted API key:", encrypted_key)
    
    # Decrypt API key
    decrypted_key = key_manager.decrypt_api_key(encrypted_key)
    print("Decrypted API key:", decrypted_key)
    
    # Initialize JWT handler
    jwt_handler = JWTHandler()
    print("JWT Handler initialized")
    
    # Create sample token
    token = jwt_handler.create_access_token({"sub": "user@example.com", "role": "admin"})
    print("Sample JWT token:", token)
    
    # Decode token
    decoded = jwt_handler.decode_token(token)
    print("Decoded token:", decoded)
    
    print("\nSecurity module is working correctly")
    input("Press Enter to exit...")

if __name__ == "__main__":
    main()
