import sys
import os
import subprocess

def main():
    print("QT.AI - Docker Setup Utility")
    print("---------------------------")
    
    # Check if Docker is installed
    try:
        subprocess.run(["docker", "--version"], check=True, capture_output=True)
        print("Docker is installed")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("Docker is not installed or not in PATH")
        print("Please install Docker Desktop from https://www.docker.com/products/docker-desktop")
        input("Press Enter to exit...")
        return
    
    # Check if Docker Compose is installed
    try:
        subprocess.run(["docker-compose", "--version"], check=True, capture_output=True)
        print("Docker Compose is installed")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("Docker Compose is not installed or not in PATH")
        print("Please install Docker Compose from https://docs.docker.com/compose/install/")
        input("Press Enter to exit...")
        return
    
    # Create Docker files
    print("Creating Docker configuration files...")
    
    # Create Dockerfile.backend
    with open("Dockerfile.backend", "w") as f:
        f.write("""FROM python:3.12-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app/ app/
COPY run_api.py .

EXPOSE 8000

CMD ["python", "run_api.py"]
""")
    print("Created Dockerfile.backend")
    
    # Create Dockerfile.frontend
    with open("Dockerfile.frontend", "w") as f:
        f.write("""FROM node:20-alpine as build

WORKDIR /app

COPY frontend/package*.json ./
RUN npm install

COPY frontend/ ./
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY frontend/nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
""")
    print("Created Dockerfile.frontend")
    
    # Create nginx.conf
    os.makedirs("frontend", exist_ok=True)
    with open("frontend/nginx.conf", "w") as f:
        f.write("""server {
    listen 80;
    server_name localhost;

    location / {
        root /usr/share/nginx/html;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://backend:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
""")
    print("Created frontend/nginx.conf")
    
    # Create docker-compose.yml
    with open("docker-compose.yml", "w") as f:
        f.write("""version: '3.8'

services:
  backend:
    build:
      context: .
      dockerfile: Dockerfile.backend
    ports:
      - "8000:8000"
    environment:
      - JWT_SECRET=your_jwt_secret_key
      - ENCRYPTION_KEY=your_encryption_key
    volumes:
      - ./app:/app/app
    restart: unless-stopped

  frontend:
    build:
      context: .
      dockerfile: Dockerfile.frontend
    ports:
      - "80:80"
    depends_on:
      - backend
    restart: unless-stopped
""")
    print("Created docker-compose.yml")
    
    print("\nDocker setup is complete")
    print("To build and start the containers, run: docker-compose up -d")
    input("Press Enter to exit...")

if __name__ == "__main__":
    main()
